//
//  EmployeeViewController.swift
//  EmployeesFirebase
//
//  Created by AamirNakhwa on 11/13/18.
//  Copyright © 2018 AamirNakhwa. All rights reserved.
//

import UIKit
import Firebase

class EmployeeViewController: UIViewController {

    var ref: DatabaseReference!
    
    var rec:Employee! = nil
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        ref = Database.database().reference()
        
        if rec != nil{
            txtName.text = rec.Name
            txtEmail.text = rec.Email
            txtAge.text = rec.Age
        }

        // Do any additional setup after loading the view.
    }

    @IBAction func btnSave(_ sender: Any) {
        let emp = ["Name": self.txtName.text!,
                   "Age": self.txtAge.text!,
                   "Email": self.txtEmail.text!]
        
        if rec == nil{
            print("Add")
            ref.child("Employees").childByAutoId().updateChildValues(emp)
        }
        else
        {
            print("update")
            ref.child("Employees").child(rec.autoID).updateChildValues(emp)
        }
        //self.dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
