//
//  Employee.swift
//  EmployeesFirebase
//
//  Created by AamirNakhwa on 11/13/18.
//  Copyright © 2018 AamirNakhwa. All rights reserved.
//

import Foundation

struct Employee
{
    var autoID:String
    var Name:String
    var Age:String
    var Email:String
    
}
