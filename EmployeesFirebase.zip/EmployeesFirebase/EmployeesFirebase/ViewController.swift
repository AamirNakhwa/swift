//
//  ViewController.swift
//  EmployeesFirebase
//
//  Created by AamirNakhwa on 11/13/18.
//  Copyright © 2018 AamirNakhwa. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var ref: DatabaseReference!
    
    var data = [String:Employee]()

    @IBOutlet weak var tableView: UITableView!
    @IBAction func btnNew(_ sender: Any) {
        performSegue(withIdentifier: "New", sender: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.dataSource = self
        tableView.delegate = self
        
        ref = Database.database().reference()
        
        ref.child("Employees").observe(.childAdded) {(snapshot) in
            print(snapshot)
            
            let autoID = snapshot.key
            let obj = snapshot.value as! [String:String]
            let name = obj["Name"] as! String
            let email = obj["Email"] as! String
            let age = obj["Age"] as! String
            self.data[autoID] = Employee(autoID: autoID, Name: name, Age: age, Email: email)
            self.tableView.reloadData()
        }
        ref.child("Employees").observe(.childRemoved) {(snapshot) in
            let autoID = snapshot.key
            self.data[autoID] = nil
            self.tableView.reloadData()
        }
        ref.child("Employees").observe(.childChanged) {(snapshot) in
            let autoID = snapshot.key
            let obj = snapshot.value as! [String:String]
            let name = obj["Name"] as! String
            let email = obj["Email"] as! String
            let age = obj["Age"] as! String
            
            self.data[autoID] = Employee(autoID: autoID, Name: name, Age: age, Email: email)
            self.tableView.reloadData()
        }
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! EmployeeTableViewCell
        var arr:Array<Employee> = Array(self.data.values)
        cell.lblName.text = arr[indexPath.row].Name
        cell.lblEmail.text = arr[indexPath.row].Email
        cell.lblAge.text = arr[indexPath.row].Age
        return cell;
        
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            var arr:Array<String> = Array(self.data.keys)
            
            self.ref.child("Employees").child(arr[indexPath.row]).removeValue()
            self.data[arr[indexPath.row]] = nil
            tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return CGFloat(120)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "New"{
            
            if sender != nil {
                
                let destination = segue.destination as! EmployeeViewController
                destination.rec = sender as! Employee
            }
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "New", sender:  self.data[Array(self.data.keys)[indexPath.row]])
    }
    
    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

