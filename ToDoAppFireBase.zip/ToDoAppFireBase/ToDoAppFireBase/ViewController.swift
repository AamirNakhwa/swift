//
//  ViewController.swift
//  ToDoAppFireBase
//
//  Created by AamirNakhwa on 11/13/18.
//  Copyright © 2018 AamirNakhwa. All rights reserved.
//

import UIKit
import FirebaseDatabase

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var ref: DatabaseReference!
    
    @IBOutlet weak var TaskTableView: UITableView!
    
    var data = [String:String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        TaskTableView.dataSource = self
        TaskTableView.delegate = self
        
        ref = Database.database().reference()
        
        ref.child("Tasks").observe(.childAdded) {(snapshot) in
            let autoID = snapshot.key
            print(snapshot.value)
            let obj = snapshot.value as! [String:String]
            let task = obj["Task"] as! String
            self.data[autoID] = task
            self.TaskTableView.reloadData()
        }
        ref.child("Tasks").observe(.childRemoved) {(snapshot) in
            let autoID = snapshot.key
            self.data[autoID] = nil
            self.TaskTableView.reloadData()
        }
        ref.child("Tasks").observe(.childChanged) {(snapshot) in
            let autoID = snapshot.key
            let obj = snapshot.value as! [String:String]
            self.data[autoID] = obj["Task"] as! String
            self.TaskTableView.reloadData()
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            var arr:Array<String> = Array(self.data.keys)
            
            self.ref.child("Tasks").child(arr[indexPath.row]).removeValue()
            self.data[arr[indexPath.row]] = nil
            TaskTableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //performSegue(withIdentifier: "NewTask", sender: self.data[Array(self.data.keys)[indexPath.row]])
        
        var Task:(String, String) = (Array(self.data.keys)[indexPath.row], Array(self.data.values)[indexPath.row])
        performSegue(withIdentifier: "NewTask", sender: Task)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print(segue.identifier)
        if segue.identifier == "NewTask"{
            
            if let s = sender as? (String?, String?)
            {
                print(s)
                let destination = segue.destination as! NewTaskViewController
                destination.Task = s as! (String?, String?)
            }
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: "Task")
        var arr:Array<String> = Array(self.data.values)
        cell.textLabel?.text = arr[indexPath.row]
        return cell;
        
        //return UITableViewCell(style: .default, reuseIdentifier: "cell")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

