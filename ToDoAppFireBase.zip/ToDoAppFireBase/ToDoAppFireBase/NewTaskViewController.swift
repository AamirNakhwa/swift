//
//  NewTaskViewController.swift
//  ToDoAppFireBase
//
//  Created by AamirNakhwa on 11/13/18.
//  Copyright © 2018 AamirNakhwa. All rights reserved.
//

import UIKit
import FirebaseDatabase

class NewTaskViewController: UIViewController {

    var ref: DatabaseReference!
    
    var Task:(String?, String?) = (nil, nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        
        if let val = Task.1
        {
            txtNewTask.text = val
        }
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var txtNewTask: UITextField!
    
    @IBAction func btnSave(_ sender: Any) {
        let task = ["Task": self.txtNewTask.text!]
        
        if Task.0 == nil{
            print("Add")
            ref.child("Tasks").childByAutoId().updateChildValues(task)
        }
        else
        {
            print("update")
            ref.child("Tasks").child(Task.0!).updateChildValues(task)
        }
        
        dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
